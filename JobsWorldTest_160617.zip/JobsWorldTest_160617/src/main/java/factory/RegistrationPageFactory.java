package factory;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class RegistrationPageFactory {

	WebDriver driver; 
 
	// mapping and declaration of webelements 
	@FindBy(id="usrID")
	@CacheLookup
	WebElement uId;
	@FindBy(id="pwd")
	@CacheLookup
	WebElement pword;
	@FindBy(id="usrname")
	@CacheLookup
	WebElement name;
	@FindBy(id="addr")
	@CacheLookup
	WebElement add;
	@FindBy(name="country")
	@CacheLookup
	WebElement country;
	@FindBy(name="zip")
	@CacheLookup
	WebElement zipcode;
	@FindBy(name="email")
	@CacheLookup
	WebElement eMail;
	@FindBy(xpath = "/html/body/form/ul/li[16]/input")
	@CacheLookup
	WebElement male;
	@FindBy(xpath = "/html/body/form/ul/li[17]/input")
	@CacheLookup
	WebElement female;
	@FindBy(name="submit")
	@CacheLookup
	WebElement btn;

	// setter methods for webElements
	public void setUserId (String id) {
		uId.sendKeys(id);
	}

	public void setPassword (String pwd) {
		pword.sendKeys(pwd);
	}

	public void setName (String nm) {
		name.sendKeys(nm);
	}

	public void setAddress (String addr) {
		add.sendKeys(addr);
	}

	public void setCountry (String ctry) {
		country.sendKeys(ctry);
	}

	public void setZipCode (String zip) {
		zipcode.sendKeys(zip);
	}

	public void setEmail (String mail) {
		eMail.sendKeys(mail);
	}

	public void setSex (String sex) {
		if(sex.equals("male"))
			male.click();
		else
			female.click();
	}

	public void clickButton () {
		btn.click();
	}

	//constructor from super class
	public RegistrationPageFactory() {
		super();
		// TODO Auto-generated constructor stub
	}

	// constructor using driver field 
	public RegistrationPageFactory(WebDriver driver) {
		super();
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}


}

