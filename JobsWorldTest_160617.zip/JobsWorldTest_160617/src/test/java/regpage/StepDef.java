package regpage;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import factory.RegistrationPageFactory;

public class StepDef {
	WebDriver driver;
	RegistrationPageFactory regPage;

	@Given("^User is on registration page$")
	public void user_is_on_registration_page() throws Throwable {
		
		System.setProperty("webdriver.chrome.driver", "D:\\\\BDD software\\\\chromedriver\\\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("D:\\BDD software\\WebPages_for test\\RegistrationForm.html"); 
		regPage = new RegistrationPageFactory(driver);
	}

	@When("^UserId Is blank$")
	public void userid_Is_blank() throws Throwable {
		regPage.setUserId("");
		regPage.clickButton();
	}

	@Then("^Display Alert 'User Id should not be empty / length be between (\\d+) to (\\d+)'$")
	public void display_Alert_User_Id_should_not_be_empty_length_be_between_to(int arg1, int arg2) throws Throwable {
		String actualErrMsg=driver.switchTo().alert().getText();
		String expErrorMsg="User Id should not be empty / length be between 5 to 12";
		Assert.assertEquals(expErrorMsg, actualErrMsg);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^UserId Is invalid$")
	public void userid_Is_invalid() throws Throwable {
		regPage.setUserId("ABCD");
		regPage.clickButton();
	}

	@When("^Password is blank$")
	public void password_is_blank() throws Throwable {
		regPage.setUserId("ABCDEF");
		regPage.setPassword("");
		regPage.clickButton();
	}

	@Then("^Display Alert 'Password should not be empty / length be between (\\d+) to (\\d+)'$")
	public void display_Alert_Password_should_not_be_empty_length_be_between_to(int arg1, int arg2) throws Throwable {
		String actualErrMsg=driver.switchTo().alert().getText();
		String expErrorMsg="Password should not be empty / length be between 7 to 12";
		Assert.assertEquals(expErrorMsg, actualErrMsg);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^Password Is invalid$")
	public void password_Is_invalid() throws Throwable {
		regPage.setUserId("ABCDEF");
		regPage.setPassword("MNBVC");
		regPage.clickButton();
	}

	@When("^Name Is blank$")
	public void name_Is_blank() throws Throwable {
		regPage.setUserId("ABCDEF");
		regPage.setPassword("MNBVCXZA");
		regPage.setName("");
		regPage.clickButton();
	}

	@Then("^Display Alert 'Name should not be empty and must have alphabet characters only'$")
	public void display_Alert_Name_should_not_be_empty_and_must_have_alphabet_characters_only() throws Throwable {
		String actualErrMsg=driver.switchTo().alert().getText();
		String expErrorMsg="Name should not be empty and must have alphabet characters only";
		Assert.assertEquals(expErrorMsg, actualErrMsg);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^Name Is invalid$")
	public void name_Is_invalid() throws Throwable {
		regPage.setUserId("ABCDEF");
		regPage.setPassword("MNBVCXZA");
		regPage.setName("A123BCD");
		regPage.clickButton();
	}

	@When("^Address Is blank$")
	public void address_Is_blank() throws Throwable {
		regPage.setUserId("ABCDEF");
		regPage.setPassword("MNBVCXZA");
		regPage.setName("ABCDEF");
		regPage.setAddress("");
		regPage.clickButton();
	}

	@Then("^Display Alert 'User address must have alphanumeric characters only'$")
	public void display_Alert_User_address_must_have_alphanumeric_characters_only() throws Throwable {
		String actualErrMsg=driver.switchTo().alert().getText();
		String expErrorMsg="User address must have alphanumeric characters only";
		Assert.assertEquals(expErrorMsg, actualErrMsg);
		driver.switchTo().alert().accept();
		driver.close(); 
	}

	@When("^Address Is invalid$")
	public void address_Is_invalid() throws Throwable {
		regPage.setUserId("ABCDEF");
		regPage.setPassword("MNBVCXZA");
		regPage.setName("ABCDEF");
		regPage.setAddress("56@DF..");
		regPage.clickButton();
	}

	@When("^Country is not selected$")
	public void country_is_not_selected() throws Throwable {
		regPage.setUserId("ABCDEF");
		regPage.setPassword("MNBVCXZA");
		regPage.setName("ABCDEF");
		regPage.setAddress("ABHJK56533");
		regPage.clickButton();
	}

	@Then("^Display Alert 'Select your country from the list'$")
	public void display_Alert_Select_your_country_from_the_list() throws Throwable {
		String actualErrMsg=driver.switchTo().alert().getText();
		String expErrorMsg="Select your country from the list";
		Assert.assertEquals(expErrorMsg, actualErrMsg);
		driver.switchTo().alert().accept();
		driver.close();// 
	}

	@When("^ZipCode is invalid$")
	public void zipcode_is_invalid() throws Throwable {
		regPage.setUserId("ABCDEF");
		regPage.setPassword("MNBVCXZA");
		regPage.setName("ABCDEF");
		regPage.setAddress("ABHJK56533");
		regPage.setCountry("India");
		regPage.setZipCode("avr576");
		regPage.clickButton();
	}

	@Then("^Display Alert 'ZIP code must have numeric characters only'$")
	public void display_Alert_ZIP_code_must_have_numeric_characters_only() throws Throwable {
		String actualErrMsg=driver.switchTo().alert().getText();
		String expErrorMsg="ZIP code must have numeric characters only";
		Assert.assertEquals(expErrorMsg, actualErrMsg);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^Email is invalid$")
	public void email_is_invalid() throws Throwable {
		regPage.setUserId("ABCDEF");
		regPage.setPassword("MNBVCXZA");
		regPage.setName("ABCDEF");
		regPage.setAddress("ABHJK56533");
		regPage.setCountry("India");
		regPage.setZipCode("56895");
		regPage.setEmail("amit");
		regPage.clickButton();
	}

	@Then("^Display Alert 'You have entered an invalid email address!'$")
	public void display_Alert_You_have_entered_an_invalid_email_address() throws Throwable {
		String actualErrMsg=driver.switchTo().alert().getText();
		String expErrorMsg="You have entered an invalid email address!";
		Assert.assertEquals(expErrorMsg, actualErrMsg);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^Gender is not selected$")
	public void gender_is_not_selected() throws Throwable {
		regPage.setUserId("ABCDEF");
		regPage.setPassword("MNBVCXZA");
		regPage.setName("ABCDEF");
		regPage.setAddress("ABHJK56533");
		regPage.setCountry("India");
		regPage.setZipCode("56895");
		regPage.setEmail("amit@cag.com");
		regPage.clickButton();
	}

	@Then("^Display Alert 'Please Select gender'$")
	public void display_Alert_Please_Select_gender() throws Throwable {
		String actualErrMsg=driver.switchTo().alert().getText();
		String expErrorMsg="Please Select gender";
		Assert.assertEquals(expErrorMsg, actualErrMsg);
		driver.switchTo().alert().accept();
		driver.close();
	}
}
